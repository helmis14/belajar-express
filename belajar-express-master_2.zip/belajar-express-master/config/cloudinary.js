const cloudinaryConfig = require('cloudinary').v2;

cloudinaryConfig.config({
    cloud_name: 'eterno', 
    api_key: '157965674852962', 
    api_secret: 'WPMAbQ06AvReY1oumvyg0BKK1nk'
});

module.exports = cloudinaryConfig;